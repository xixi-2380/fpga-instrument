Existing user build completed 2026-10-25 11:27, Gowin V1.9.12.04, GW5AST-LV138FPG676AC1/I0 Version C.
TIMING FAILED: ref 43.703/50 MHz, audio 40.291/61.44 MHz, pixel 25.897/35 MHz.
Archived for development traceability; not a timing-qualified firmware. No assistant build or programming performed.
See docs/bluetooth_score release notes and reports/release_bluetooth_2026-10-25.
